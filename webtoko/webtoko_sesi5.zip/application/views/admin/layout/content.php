<?php
// memanggil data isi content dari controller variable isi
if( $isi )
{
	$this ->load->view($isi);
}
<?php
//mengambil data isi content website di controller (dari variabel isi)
if( $isi )
{
	$this->load->view($isi);
}